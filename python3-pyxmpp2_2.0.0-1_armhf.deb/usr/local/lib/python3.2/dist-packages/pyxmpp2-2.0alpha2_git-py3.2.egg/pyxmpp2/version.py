# pylint: disable=C0111,C0103
version = '2.0alpha2-git'
